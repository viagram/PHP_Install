<?php

class c {
	const TESTCONSTANT = "c::TESTCONSTANT";
}
